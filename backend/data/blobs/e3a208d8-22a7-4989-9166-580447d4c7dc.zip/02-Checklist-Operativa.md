---
type: checklist
owner: Nazar
created: 2026-05-20
related: "[[01-Master-Plan-2026-2032]]"
tags: [checklist, operations, habits]
---

# Checklist Operativa

> Da consultare quotidianamente. Spuntare/aggiornare in tempo reale.
> Le check non spuntate restano visibili come debito operativo.

---

## Quotidiana

### Mattina (sveglia 7:30)
- [ ] Cane camminata 20-30min
- [ ] Bottiglia d'acqua piena sul tavolo lavoro
- [ ] Lavoro Comau 9:00-18:00

### Sera (post-lavoro)
- [ ] **Speexx 30min** (slot fisso 18:00-18:30)
- [ ] Attività primaria della giornata (palestra OR vision/robot study OR lettura — secondo schema settimanale)
- [ ] Cena entro le 20:30
- [ ] Cane camminata serale 20-30min

### Pre-sonno (entro 22:30)
- [ ] Telefono FUORI dalla camera (carica in altra stanza)
- [ ] Lettura libro fisico 30min (NO YouTube serale)
- [ ] Luce calda, no schermi
- [ ] Sveglia: Fitbit Air o analogica

### Daily note (opzionale primi 60 giorni)
- [ ] 5-10min: 3 cose fatte, 1 imparata, 1 ostacolo (template in `04-Templates-Obsidian.md`)

---

## Settimanale

### Lunedì
- [ ] NotebookLM session Cognex 30min
- [ ] Pianificazione settimana (5min review priorità)

### Martedì
- [ ] Palestra (sessione 1/2)
- [ ] Cardio extra indoor 45min (cyclette/tapis) — se non palestra

### Mercoledì
- [ ] Cognex Emulator implementation 60min
- [ ] Commento LinkedIn 1 post tecnico altri (network touch passivo)

### Giovedì
- [ ] Palestra (sessione 2/2)
- [ ] Cardio extra indoor 45min — se non palestra

### Venerdì
- [ ] Obsidian documentation (case study settimana) 30min
- [ ] Conversazione inglese tutor 45-60min (italki/Cambly)
- [ ] 1 conversazione non transazionale network (call, message LinkedIn sostantivo)

### Sabato
- [ ] Deposito padre 4-5h (Legna Pellet)
- [ ] Case study Cognex end-to-end 90min
- [ ] Corsa o cardio (1.5h totali) — outdoor maggio-ottobre se parietaria ok, altrimenti indoor

### Domenica
- [ ] Dormita lunga + recupero
- [ ] **Weekly Review 45min** (template in `04-Templates-Obsidian.md`)
- [ ] Pianificazione prossima settimana (priorità 1-3 + 1 esperimento)
- [ ] Backup vault Obsidian
- [ ] Tempo qualità con compagna (cena lunga, niente schermi)

### Bi-settimanale
- [ ] **1 post LinkedIn tecnico** (problema vision/robot risolto, sanificato, post-mortem format)

---

## Mensile

### Settimana 1 del mese
- [ ] Iniziare nuovo libro (pipeline lettura, vedi Master Plan)
- [ ] Review investimenti BG Saxo (max 30min, no trading impulsivo)
- [ ] Body check: peso, foto, misure
- [ ] Update Network-CRM (chi ho perso vista? recovery touch)

### Settimana 2-3
- [ ] Lettura libro corrente in corso
- [ ] Esecuzione priorità tecniche (corso Cognex / robot study)

### Settimana 4 del mese
- [ ] **Distillare libro completato** via Gem Book Knowledge Extractor → salvare in `04-Knowledge/Books/`
- [ ] Update Master Plan: milestone slittate? Cambiamenti contesto?
- [ ] Backup completo vault Obsidian
- [ ] Review spese mese vs budget

---

## Trimestrale

### Inizio trimestre
- [ ] **Review profonda Master Plan** (1-2h): tesi centrale ancora valida?
- [ ] Ricalibrare priorità se ci sono shift di contesto
- [ ] Pianificare apprendimenti tecnici trimestre (es. Q2: Cognex ViDi, Q3: ABB intermediate)
- [ ] Body check: peso, composizione (se possibile), foto comparativa

### Durante trimestre
- [ ] Skill audit: cosa ho imparato vs piano
- [ ] Networking review: chi è entrato nel CRM? Chi è uscito? Touch programmato per i top 5
- [ ] Budget review (post-convivenza dal 2026)
- [ ] Review portafoglio: ribilanciamento se asset allocation deviata >5%

### Fine trimestre
- [ ] Aggiornamento PROJECT_STATE.md di MiRa Companion (se progetto attivo)
- [ ] Backup Git del vault Obsidian (oltre al sync)

---

## Annuale

### Q1 dell'anno
- [ ] **Visita medico di base + esami ematici completi**
  - Emocromo, glicemia, lipidi, funzionalità epatica/renale
  - TSH, vitamina D, B12, ferritina
  - Pressione arteriosa
  - Aggiornamento screening allergologico parietaria
- [ ] Dichiarazione redditi: appuntamento commercialista (quadro RW IVAFE, capital gain)
- [ ] Review polizza vita + invalidità (eventuali adeguamenti)
- [ ] Review fondo pensione (versamenti, performance, deducibilità)

### Q2 dell'anno
- [ ] **SPS Italia Parma** (fiera automation, maggio) — riserva giornata + biglietto
- [ ] Ricalibrazione Master Plan a metà anno
- [ ] Eventuale richiesta nuove certificazioni Cognex / robot (corso da pianificare H2)

### Q3 dell'anno
- [ ] **Vision Show Stuttgart** (o altra fiera europea vision, autunno) — valutare
- [ ] Riferimento per inglese: test progressi C1 (mock test Cambridge/LanguageCert)

### Q4 dell'anno
- [ ] Review annuale completa:
  - Milestone 2026 raggiunte? Quante slittate?
  - Tesi centrale ancora valida?
  - Cambiamenti contesto (mercato vision, situazione personale)
  - Confidence aggiornata
- [ ] Pianificazione anno successivo: milestone macro, priorità, allocazione tempo
- [ ] Decisione fiscale: ottimizzazione fine anno (versamenti deducibili, capital gain crystallization)

### One-shot 2026
- [ ] Consulenza una tantum commercialista Napoli specializzato P.IVA tecnici (entro Q3)
- [ ] Polizza TCM + Invalidità Permanente quotazione (Genertel, Genialloyd, broker indipendente)
- [ ] Trasferimento TFR a fondo pensione (Cometa CCNL metalmeccanici o aperto)

---

## Metriche da tracciare (Habits-Tracker.md separato)

### Quotidiane (checkbox)
| Habit | Mon | Tue | Wed | Thu | Fri | Sat | Sun |
|---|---|---|---|---|---|---|---|
| Speexx 30min | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| Lettura 30min | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| Telefono fuori camera | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| Cane 2x | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |

### Settimanali (numero)
- Palestra (target: 2)
- Cardio extra (target: 2)
- Vision/robot study (target: 6-8h)
- Conversazione inglese tutor (target: 1)
- Network touch (target: 1)
- Sonno medio ore (target: 7+)

### Mensili (numero)
- Libri completati (target: 1)
- Post LinkedIn (target: 2)
- Peso kg (target: -0.5/-1.0 fino a 76)
- Spese vs budget (delta %)

---

## Note operative

- **Checklist senza spunta a fine settimana ≠ fallimento.** È data per la weekly review: capire perché.
- **Streak conta meno della direzione.** Saltare 1 giorno è ok. Saltare 7 giorni indica problema sistemico.
- **Adattamenti permessi, deviazioni inerziali no.** Se cambi un habit, scrivi perché nella weekly review.

---

*Aggiornare quando il Master Plan cambia.*
