---
type: templates-collection
owner: Nazar
created: 2026-05-20
tags: [templates, obsidian]
---

# Templates Obsidian — Set Completo

> Copia ogni template in un file separato dentro `99-Templates/` del vault.
> Usa il plugin **Templater** o **core Templates** di Obsidian per istanziarli.

---

## Struttura del Vault consigliata

```
Nazar-Vault/
├── 00-Inbox/                       ← cattura veloce, smistare in weekly review
├── 01-Daily/                       ← daily notes brevi (opzionale primi 60gg)
├── 02-Weekly-Reviews/              ← weekly review domenicali
├── 03-Plans/
│   ├── 01-Master-Plan-2026-2032.md
│   ├── 02-Checklist-Operativa.md
│   ├── Goals-Tracking.md           ← metriche aggregate
│   └── Habits-Tracker.md           ← tracking quotidiano
├── 04-Knowledge/
│   ├── Books/                      ← output Gem Book Extractor
│   ├── Mental-Models/              ← un file per modello (Inversion, Moat, ecc)
│   ├── Frameworks/                 ← Priestley, Buffett DCF, RIPER-5, ecc
│   └── Concepts/                   ← concetti tecnici (matrici rotazione, hand-eye calib, ecc)
├── 05-Work-Comau/
│   ├── Vision-Cognex/
│   │   ├── Concepts/               ← tool/funzioni Cognex
│   │   ├── Case-Studies/           ← portfolio sanificato
│   │   └── Reference/              ← snippets, screenshot, formule
│   ├── Robot-Programming/
│   │   ├── ABB-RAPID/
│   │   ├── KUKA-KRL/
│   │   └── Fanuc-TP/
│   ├── Plant-Visits/               ← log ogni trasferta
│   └── Daily-Work-Log/             ← opzionale, lavoro quotidiano
├── 06-Side-Projects/
│   ├── Legna-Pellet/
│   └── MiRa-Companion/
│       └── PROJECT_STATE.md        ← anchor multi-sessione AI
├── 07-Finance/
│   ├── Portfolio-Tracking.md
│   ├── Budget-Mensile.md
│   ├── Tax-Notes-IT.md             ← IVAFE, RW, 26% cap gain, P.IVA notes
│   └── Investment-Theses/
├── 08-Learning/
│   ├── English-Speexx/             ← log progressi, vocaboli, errori ricorrenti
│   ├── Robot-Programming-Study/
│   └── Cognex-Certifications/
├── 09-Personal/
│   ├── Health-Log.md               ← peso, sonno, esami, screening
│   ├── Network-CRM.md              ← contatti rilevanti + ultimo touch
│   ├── Reading-Pipeline.md         ← libri da leggere ordinati per priorità
│   └── Life-Decisions.md           ← decisioni importanti con razionale
└── 99-Templates/                   ← questi template
```

---

## Template 1 — Weekly Review

**File:** `99-Templates/weekly-review.md`

```markdown
---
date: {{date:YYYY-MM-DD}}
type: weekly-review
week: {{date:GGGG-[W]ww}}
mood: 
energy: 
tags: [weekly-review]
---

# Weekly Review — Settimana {{date:GGGG-[W]ww}}

## 1. Cosa ho fatto (max 7 punti, concreti)
- 
- 
- 

## 2. Cosa ho imparato
**Tecnicamente:**
- 

**Su me stesso / su come lavoro:**
- 

## 3. Dove mi sono bloccato
Situazioni concrete di procrastinazione, evitamento, blocco:
- 

Pattern ricorrente identificato?
- 

## 4. Decisioni prese
- **Cosa:** 
- **Perché:** 
- **Alternativa scartata e motivo:** 

## 5. Metriche settimanali
| Area | Target | Risultato | Δ | Note |
|------|--------|-----------|---|------|
| Speexx (min/gg medio) | 30 | | | |
| Lettura (min/gg medio) | 30 | | | |
| Palestra (sessioni) | 2 | | | |
| Cardio extra (sessioni) | 2 | | | |
| Vision/robot study (h) | 6-8 | | | |
| Conversazione inglese tutor | 1 | | | |
| Network touch | 1 | | | |
| Sonno medio (h) | 7+ | | | |
| Peso (kg) | tracking | | | |
| Telefono fuori camera (gg) | 7 | | | |

## 6. Prossima settimana

**Priorità (max 3):**
1. 
2. 
3. 

**1 esperimento nuovo:**
- 

**Da delegare/eliminare:**
- 

## 7. Confidence sul piano lungo periodo (Master Plan)
**Score:** [0.0 - 1.0]
**Motivo breve (max 1 riga):**

## 8. Domanda della settimana
*Una domanda aperta che vuoi tenere viva per la prossima settimana:*

## 9. Inbox da smistare
*Cosa è arrivato in `00-Inbox/` questa settimana che va archiviato/elaborato:*
- [ ] 
- [ ] 

---
**Link:** [[01-Master-Plan-2026-2032]] | [[02-Checklist-Operativa]]
```

---

## Template 2 — Daily Note (opzionale)

**File:** `99-Templates/daily-note.md`

```markdown
---
date: {{date:YYYY-MM-DD}}
type: daily
weekday: {{date:dddd}}
mood: 
energy: 
sleep: 
tags: [daily]
---

# {{date:dddd DD MMMM YYYY}}

## 3 cose fatte oggi
1. 
2. 
3. 

## 1 cosa imparata oggi
- 

## 1 ostacolo o frustrazione
- 

## Note sparse
- 

## Domani: 1 priorità
- 
```

---

## Template 3 — Book Note (output Gem)

**File:** `99-Templates/book-note.md`

> Questo template è popolato dalla Gem "Book Knowledge Extractor" su Gemini.
> Vedi `03-Book-Knowledge-Extractor.md` per il prompt completo.
> Il template sotto è solo struttura: la Gem produce contenuto.

```markdown
---
title: 
author: 
year: 
category: 
read_date: 
rating: 
mode: full | refresh
tags: [book, ]
---

# 

## TL;DR


## Core Ideas

### 


## Mental Models / Frameworks


## Anti-tesi e limiti


## Domande aperte


## Connessioni
- [[]]

## Action Items
- [ ] 
- [ ] 

---
**Link:** [[Reading-Pipeline]]
```

---

## Template 4 — Plant Visit Log

**File:** `99-Templates/plant-visit.md`

```markdown
---
date_start: {{date:YYYY-MM-DD}}
date_end: 
plant_name: 
client: 
location: 
country: 
robot_vendor: [ABB | Fanuc | KUKA | Comau | other]
vision_system: [Cognex In-Sight | DataMan | other]
purpose: [setup | troubleshooting | optimization | training | acceptance]
tags: [plant-visit, comau-work]
---

# Plant Visit — {{date:YYYY-MM-DD}} —  

## Contesto
- Stazione/linea: 
- Problema iniziale: 

## Setup tecnico
- Vision system: 
- Robot: 
- PLC: 
- Communication: 

## Cosa ho fatto
- 

## Problemi incontrati
- 

## Soluzioni applicate
- 

## Cosa ho imparato
- 

## Case study sanificabile?
- [ ] Sì, può diventare post LinkedIn dopo sanificazione
- **Highlights da sanificare prima di pubblicare:**
  - 

## Contatti incontrati (→ Network-CRM)
- Nome — Ruolo — Azienda — Touch follow-up:

## Follow-up tecnici per me
- [ ] 
- [ ] 

---
**Link:** [[05-Work-Comau/Vision-Cognex]] | [[Network-CRM]]
```

---

## Template 5 — Network Contact

**File:** `99-Templates/network-contact.md`

```markdown
---
name: 
role: 
company: 
location: 
relationship: [colleague | ex-colleague | client | partner | vendor | community]
last_touch: 
next_touch_planned: 
linkedin: 
tags: [network]
---

# 

## Profilo professionale
- Ruolo attuale: 
- Background: 
- Expertise specifica: 

## Come ci siamo conosciuti


## Argomenti di valore reciproco
- 

## Touch history
- {{date:YYYY-MM-DD}} — Tipo touch — Contenuto

## Possibili sinergie future
- 

## Note personali
- 

---
**Link:** [[Network-CRM]]
```

---

## Template 6 — Project State (per progetti multi-sessione AI)

**File:** `99-Templates/project-state.md`

```markdown
---
project: 
created: {{date:YYYY-MM-DD}}
last_updated: {{date:YYYY-MM-DD}}
status: [active | paused | completed | archived]
tags: [project-state]
---

# PROJECT_STATE — 

## Tesi del progetto
*Cosa stiamo facendo e perché. 3-5 righe.*

## Stack tecnico
- Linguaggio: 
- Framework: 
- DB: 
- Versioni esatte: 

## Architettura corrente
*Diagramma testuale o link a diagramma.*

## File principali
- `path/file.ts` — ruolo
- `path/file2.ts` — ruolo

## Decisioni architetturali prese
1. **Decisione:** 
   - **Razionale:** 
   - **Trade-off accettati:** 
   - **Alternative scartate e perché:** 

## TODO aperti
- [ ] 
- [ ] 

## TODO chiusi recentemente
- [x] 
- [x] 

## Debt tecnici noti
- 

## Prossimo step concreto
- 

---
**Aggiornamento dopo ogni sessione significativa.**
```

---

## Template 7 — Investment Thesis

**File:** `99-Templates/investment-thesis.md`

```markdown
---
ticker: 
name: 
sector: 
country: 
date_thesis: {{date:YYYY-MM-DD}}
position_size: 
entry_price: 
target_horizon: 
confidence: 
tags: [investment, thesis, buffett-munger]
---

# Investment Thesis — 

## Business in 3 righe


## Moat (durable competitive advantage)
- 

## Capital allocation (management)
- ROIC storico:
- ROE storico:
- Reinvestimento utili:
- Dividendi/buyback:

## Valuation
- P/E attuale: 
- P/B attuale: 
- FCF yield: 
- Confronto storico: 

## Catalysts attesi (3-5 anni)
- 

## Bear case (cosa potrebbe andare male)
- 

## Trigger di uscita
- 

## Italian tax considerations
- 26% cap gain
- IVAFE 0.2% se conto estero
- Quadro RW se conto estero

---
**Link:** [[Portfolio-Tracking]] | [[Tax-Notes-IT]]
```

---

## Template 8 — Mental Model

**File:** `99-Templates/mental-model.md`

```markdown
---
name: 
discipline: [engineering | finance | psychology | biology | physics | other]
source_book: 
date_added: {{date:YYYY-MM-DD}}
tags: [mental-model]
---

# 

## Definizione in 2 righe


## Esempio canonico (originale)


## Applicazione nel contesto Nazar
- **Vision/robot lavoro:** 
- **Investimenti:** 
- **Decisioni personali:** 

## Modelli correlati
- [[Altro modello]]

## Esempi di applicazione vissuti
- {{date:YYYY-MM-DD}} — Contesto — Come applicato — Esito

---
**Link:** [[Mental-Models]]
```

---

## Setup tecnico Obsidian consigliato

### Plugin core da attivare
- **Templates** (core): per istanziare i template
- **Daily notes** (core): se attivi i daily
- **Graph view** (core): connessioni vault
- **Backlinks** (core): vedi cosa linka a cosa

### Plugin community consigliati
- **Templater**: template più potenti con script
- **Calendar**: vista calendario per daily/weekly
- **Periodic Notes**: gestisce weekly/monthly notes
- **Dataview**: query nel vault (es. tutti i libri letti quest'anno)
- **Tasks**: gestione TODO avanzata
- **Excalidraw**: diagrammi inline (utile per concetti tecnici come matrici rotazione)
- **Tag Wrangler**: gestione tag

### Configurazioni
- Sync: **Obsidian Sync** (€4/mese) o **Git** via plugin
- Mobile: app Obsidian mobile, sync abilitato
- Backup: Git repository privato GitHub (account work-non-aziendale o personale)

### Hotkeys consigliati
- `Ctrl/Cmd + N`: nuovo file
- `Ctrl/Cmd + O`: quick switcher
- `Ctrl/Cmd + P`: command palette
- `Ctrl/Cmd + Shift + F`: search vault
- Custom: `Ctrl/Cmd + T` → instanzia template Weekly Review

---

*Versione 1.0 — affinare dopo 30 giorni di uso.*
